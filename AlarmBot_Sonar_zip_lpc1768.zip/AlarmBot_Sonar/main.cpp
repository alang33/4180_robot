#include "mbed.h"
#include "ultrasonic.h"

DigitalOut led1(LED1);
 
 void dist(int distance)
{
    // This is where you place the code to perform actions depending on 
    // distance read in from sonar ( distance measured in mm)
    if (distance < 120) {
        led1 = 0;
    } else led1 = 1; 
    
    //Printing to allow viewing in a terminal window
    printf("Distance %d mm\r\n", distance); 
}
 
ultrasonic mu(p6, p7, .1, 1, &dist);    //Set the trigger pin to p6 and the echo pin to p7
                                        //have updates every .1 seconds and a timeout after 1
                                        //second, and call dist when the distance changes
 
int main()
{
    mu.startUpdates();//start measuring the distance
    while(1)
    {
        //Do something else here
        mu.checkDistance();     //call checkDistance() as much as possible, as this is where
                                //the class checks if dist needs to be called.
    }
}
